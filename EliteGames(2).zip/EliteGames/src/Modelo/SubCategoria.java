/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author 181610047
 */
public class SubCategoria {
    
    int cod_subcat;
    String descricao;

    public int getCod_subcat() {
        return cod_subcat;
    }

    public void setCod_subcat(int cod_subcat) {
        this.cod_subcat = cod_subcat;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    
    
    
}
